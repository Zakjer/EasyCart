const searchButton = document.querySelector(".search-button")
const kitchenAcesoriesBtn = document.querySelector(".accessories")
const kitchenAcesories = document.querySelector(".kitchen-accessories")
const accesoriesList = document.querySelector('.kitchen-accessories-list')    
const header = document.querySelector('.header');
const container = document.querySelector(".container")


const showList = () => {
    accesoriesList.style.display = "flex"
    kitchenAcesoriesBtn.classList.add("accessories-button-hover")
}

const hideList = () =>{
    accesoriesList.style.display = "none"
    kitchenAcesoriesBtn.classList.remove("accessories-button-hover")
}
const stickyHeader = () => {
    if (window.pageYOffset > 0) {
        header.classList.add('sticky-header');
        container.style.marginTop = "155px";
    } else {
        header.classList.remove('sticky-header');
        container.style.marginTop = "20px";
    }
}

const addToOrderList = e => {
    if(!e.target.classList.contains("fa-solid")){
        e.target.classList.add('fa-solid')
    } else {
        e.target.classList.remove('fa-solid')
    }
}

kitchenAcesoriesBtn.addEventListener('mouseover',showList)
kitchenAcesories.addEventListener('mouseleave',hideList)
searchButton.addEventListener('click', () => {console.log("HI")} )
window.addEventListener('scroll', stickyHeader)
container.addEventListener('click', addToOrderList)
  